<div class="container">
    <div class="row">
        <h1 class="mt-4">Events Manager</h1>
        <br>
        <h4>Shortcode Lists you can use for different functionality</h4>
        <ul>
            <li><b>[event_feeds]</b></li>
            <li><b>[display_cal_events]</b></li>
            <li><b>[display_term_dates]</b></li>
            <?php echo esc_url(plugins_url('events-plugin/api/ical.php')); ?>
        </ul>
    </div>
</div>
